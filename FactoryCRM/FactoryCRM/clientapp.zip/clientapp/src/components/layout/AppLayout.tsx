import { Outlet } from "react-router-dom";
import { LogoutButton } from "../LogoutButton";

export const AppLayout = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 text-white flex justify-between items-center px-6 py-4 shadow-md">
        <h1 className="text-xl font-bold">Factory CRM</h1>
        <LogoutButton />
      </header>

      {/* Main content */}
      <main className="flex-1 bg-gray-50 p-6">
        <Outlet />
      </main>
    </div>
  );
};
