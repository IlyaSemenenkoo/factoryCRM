import { Navigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { JSX } from "react";

export function ProtectedRoute({
  children,
  role,
}: {
  children: JSX.Element;
  role?: string;
}) {
  const { user, isReady } = useAuth();

  // Поки не перевірено localStorage — не рендеримо нічого
  if (!isReady) return null;

  // Неавторизовані → /login
  if (!user) return <Navigate to="/login" />;

  // Якщо вказано роль і вона не підходить → /login
  if (role && user.role !== role) return <Navigate to="/login" />;

  return children;
}
